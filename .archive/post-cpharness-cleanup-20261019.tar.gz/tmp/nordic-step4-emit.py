"""Throwaway Step 4 emitter for nordic-foods: builds the policy property map from the frozen
governance JSON and stamps SHA-256 hashes into the contract artifacts.

Usage: python3 tmp/nordic-step4-emit.py policy-map | hashes
"""

import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

DIR = Path(__file__).resolve().parents[1] / "agent-output" / "nordic-foods"
GOV = DIR / "04-governance-constraints.json"
PLAN = DIR / "04-implementation-plan.md"
MAP = DIR / "04-policy-property-map.json"
CONTRACT = DIR / "04-iac-contract.json"

NONE = "none planned"

# policy tail -> (resource_type, property_path, expected_value, evidence_required)
TARGETS = {
    "VirtualMachine_SKU_Deny": (
        "Microsoft.Compute/virtualMachines",
        "properties.hardwareProfile.vmSize",
        NONE,
        "No virtual machine is in the plan; matrix row confirms no Microsoft.Compute/virtualMachines resource is emitted.",
    ),
    "AKS_LimitNodeCount_Deny": (
        "Microsoft.ContainerService/managedClusters",
        "properties.agentPoolProfiles[*].count",
        NONE,
        "No AKS cluster is in the plan; CodeGen must not add managedClusters.",
    ),
    "VMSS_LimitNodesCount_Deny": (
        "Microsoft.Compute/virtualMachineScaleSets",
        "sku.capacity",
        NONE,
        "No virtual machine scale set is in the plan; CodeGen must not add scale sets.",
    ),
    "AzureOpenAI_ProvisionedCapacity_Deny": (
        "Microsoft.CognitiveServices/accounts/deployments",
        "sku.name",
        NONE,
        "No Azure OpenAI account or deployment is in the plan.",
    ),
    "Sentinel_Commitment_Deny": (
        "Microsoft.OperationalInsights/workspaces",
        "properties.sku.capacityReservationLevel",
        "unset (PerGB2018 pay-as-you-go)",
        "AVM module avm/res/operational-insights/workspace must set skuName PerGB2018 and no capacity reservation level.",
    ),
    "AzureSQL_WithoutAzureADOnlyAuthentication_Deny": (
        "Microsoft.Sql/servers",
        "properties.administrators.azureADOnlyAuthentication",
        True,
        "AVM module avm/res/sql/server must set administrators.azureADOnlyAuthentication true with a principalType, login and sid; no SQL administrator login or password.",
    ),
    "AzureSQLMI_WithoutAzureADOnlyAuthentication_Deny": (
        "Microsoft.Sql/managedInstances",
        "properties.administrators.azureADOnlyAuthentication",
        NONE,
        "No SQL managed instance is in the plan.",
    ),
    "6c112d4e-5bc7-47ae-a041-ea2d9dccd749": (
        "Microsoft.ClassicCompute/virtualMachines",
        "type",
        NONE,
        "No resource type on the assignment's listOfResourceTypesNotAllowed (all classic types) is emitted; verified against every planned type.",
    ),
    "KeyVaultManagedHSM_PurgeProtectionEnabled_Deny": (
        "Microsoft.KeyVault/managedHSMs",
        "properties.enablePurgeProtection",
        NONE,
        "Only a standard Microsoft.KeyVault/vaults resource is planned; no managed HSM.",
    ),
    "a15944e7-86a5-4adf-a36c-d851916c9001": (
        "Microsoft.ClassicNetwork/virtualNetworks",
        "type",
        NONE,
        "No classic (Azure Service Manager) resource type is emitted.",
    ),
    "7509877f-d414-4d79-8d1f-d600ea78d087": (
        "Microsoft.Resources/resourceGroups",
        "location",
        "swedencentral",
        "Every resource and the resource group use location swedencentral; westeurope is never emitted.",
    ),
}

RATIONALE = {
    True: "Security: Entra-only SQL authentication (SFI-ID4.2.2) removes SQL passwords; the Deny blocks the server otherwise.",
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def policy_map():
    gov = json.loads(GOV.read_text())
    seen = {}
    for f in gov["findings"]:
        if f.get("classification") != "blocker":
            continue
        seen.setdefault(f["policy_id"], f["display_name"])
    policies = []
    for policy_id, display in sorted(seen.items(), key=lambda kv: kv[1].lower()):
        tail = policy_id.rsplit("/", 1)[-1]
        rtype, path, expected, evidence = TARGETS[tail]
        applies = expected is not NONE and expected != NONE
        policies.append(
            {
                "policy_id": policy_id,
                "display_name": display,
                "effect": "Deny",
                "target_property": {"resource_type": rtype, "property_path": path, "expected_value": expected},
                "evidence_required": evidence,
                "rationale": (
                    "Applies to a planned resource; the plan satisfies it with the stated property value."
                    if applies
                    else "Not applicable by design: the resource type is absent from the plan. Recorded so a later plan change that adds it is caught."
                ),
            }
        )
    assert len(policies) == 11, len(policies)
    out = {
        "$schema": "../../tools/schemas/policy-property-map.schema.json",
        "schema_version": "policy-property-map-v1",
        "project": "nordic-foods",
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "governance_depth": "full",
        "constraints_ref": {"path": "04-governance-constraints.json", "sha256": sha(GOV)},
        "policies": policies,
    }
    MAP.write_text(json.dumps(out, indent=2, ensure_ascii=False) + "\n")
    print(f"wrote {MAP.name}: {len(policies)} policies")


def hashes():
    contract = json.loads(CONTRACT.read_text())
    contract["plan_ref"]["sha256"] = sha(PLAN)
    contract["l1m_ref"]["sha256"] = sha(MAP)
    contract["generated_at"] = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    CONTRACT.write_text(json.dumps(contract, indent=2, ensure_ascii=False) + "\n")
    print("plan", sha(PLAN)[:12], "map", sha(MAP)[:12], "gov", sha(GOV)[:12])


if __name__ == "__main__":
    {"policy-map": policy_map, "hashes": hashes}[sys.argv[1]]()
